public class Professor extends Usuario{
  
}