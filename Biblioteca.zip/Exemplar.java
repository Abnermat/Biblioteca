public class Exemplar extends Livro{
  
}