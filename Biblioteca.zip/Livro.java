public abstract class Livro{
  int codigo;
  String titulo, editora, autores, edicao, anopub;
  
}