public abstract class Usuario{
  int codigousu;
  String Nome;
  String tipousu;
  
}